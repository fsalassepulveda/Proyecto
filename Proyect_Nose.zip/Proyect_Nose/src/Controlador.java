import java.util.Scanner;
import java.util.Random;

    public class Controlador {
        Random random = new Random(System.currentTimeMillis());
        private Scanner scanner;

        Panel_de_Control panel = new Panel_de_Control();
        Contenedor robot = new Contenedor(0);

        int eleccion = 0;

        public int getRobot() {
            return robot.getCambiar();
        }

        public Controlador() {
            this.scanner = new Scanner(System.in);
        }


        public int Menu_inicio() {
            System.out.println("MENU DE OPCIONES: \n");
            System.out.println("\t (1)Iniciar pista ");

            eleccion = this.scanner.nextInt();

            while (eleccion != 1) {
                System.out.println("No es posible inicial  sin pista");
                System.out.println("MENU DE OPCIONES: \n");
                System.out.println("\t (1)Iniciar pista");
                eleccion = this.scanner.nextInt();
            }

            System.out.println("PISTA INICIADA");
            panel.estado = "Fighter";
            panel.altura = 0;
            panel.l_pista = random.nextInt(300)+50;
            System.out.println("Estado: " + panel.estado +"\n \t Altura: "+ panel.altura + " metros\n \t Largo pista: "+ panel.l_pista + " metros \n \t Velocidad inicial: 0 km/h");
            return robot.setCambiar(1);
        }











}
