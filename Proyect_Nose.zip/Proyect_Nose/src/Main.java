public class Main {

    public static void main(String [] args) {

        Controlador c;
        c = new Controlador();

        c.Menu_inicio();


    }


}
