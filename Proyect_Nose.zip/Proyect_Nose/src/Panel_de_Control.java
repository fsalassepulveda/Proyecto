public class Panel_de_Control {


    Contenedor container = new Contenedor(0);

    String estado;      //Estado del robot : Fighter, Battloid, Gerwalk
    int l_pista;    //Largo inicial de la pista, minimo = 100m
    int altura;     //Altura a la que se encuentra el robot
    int velocidad = 0;
    int delta_estados = 0;
    int pos_robot = 0;


    //Setter
    public void setContainer(Contenedor container) {
        this.container = container;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public void setL_pista(int l_pista) {
        this.l_pista = l_pista;
    }

    public void setAltura(int altura) {
        this.altura = altura;
    }

    public void setVelocidad(int velocidad) {
        this.velocidad = velocidad;
    }

    public void setDelta_estados(int delta_estados) {
        this.delta_estados = delta_estados;
    }

    public void setPos_robot(int pos_robot) {
        this.pos_robot = pos_robot;
    }

    //Getter

    public Contenedor getContainer() {
        return container;
    }

    public String getEstado() {
        return estado;
    }

    public int getL_pista() {
        return l_pista;
    }

    public int getAltura() {
        return altura;
    }

    public int getVelocidad() {
        return velocidad;
    }

    public int getDelta_estados() {
        return delta_estados;
    }

    public int getPos_robot() {
        return pos_robot;
    }


}


