public class Main {

    public static void main(String [] args) {


        Controlador control = new Controlador();
        Contenedor contenedor = new Contenedor(0);
        control.Menu_inicio();
        contenedor.getEstado();
    }


}
